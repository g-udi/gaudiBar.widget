# time

![time-widget](https://user-images.githubusercontent.com/550726/67030265-f9874380-f106-11e9-9e38-f6a6c5ea699a.png)

| Refresh Frequency             | 10000                                                                   |
|-------------------------------|-------------------------------------------------------------------------|

This widget shows the current time

