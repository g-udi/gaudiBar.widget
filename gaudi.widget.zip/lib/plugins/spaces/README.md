# spaces

![spaces-widget](https://user-images.githubusercontent.com/550726/67053418-4f74df00-f139-11e9-86fd-41875ce9894d.png)

| Refresh Frequency             | 10000                                                                   |
|-------------------------------|-------------------------------------------------------------------------|

This widget shows the current desktop number that [chunkwm](https://github.com/koekeishiya/chunkwm) assigns.