# screens

![screens-widget](https://user-images.githubusercontent.com/550726/67053261-c067c700-f138-11e9-8a4f-f363ff540931.png)

| Refresh Frequency             | 100                                                                   |
|-------------------------------|-------------------------------------------------------------------------|

This widget shows:
 - The desktop spaces available
 - Highlights the active desktop with a green background