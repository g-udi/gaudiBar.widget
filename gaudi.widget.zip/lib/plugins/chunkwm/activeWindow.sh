#!/bin/bash
echo `osascript gaudiBar.widget/lib/plugins/chunkwm/currentWindow.scpt`