# network

![network-wwidget](https://user-images.githubusercontent.com/550726/67054712-5bfb3680-f13d-11e9-8d81-6c48b396a643.png)

| Refresh Frequency             | 10000                                                                   |
|-------------------------------|-------------------------------------------------------------------------|

This widget shows:
 - Icon to indicate whether the laptop is connected to an Ethernet network or WiFi
 - The SSID of the WiFi network if available